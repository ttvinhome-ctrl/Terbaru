package id.kaabaos.tv

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val navy = Color.rgb(12, 24, 40)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout
    private lateinit var clock: TextView
    private lateinit var greeting: TextView
    private lateinit var dateText: TextView
    private lateinit var weatherText: TextView
    private lateinit var forecastText: TextView
    private lateinit var prayerText: TextView
    private lateinit var dock: LinearLayout
    private lateinit var pageLabel: TextView
    private var libraryOpen = false
    private val openedApps = linkedSetOf<String>()

    data class TvApp(val label: String, val pkg: String, val tint: Int)

    private val featured = listOf(
        TvApp("Netflix", "com.netflix.ninja", Color.rgb(229, 9, 20)),
        TvApp("YouTube", "com.google.android.youtube.tv", Color.rgb(255, 35, 35)),
        TvApp("Live TV", "com.google.android.tv.dtv", Color.rgb(65, 170, 255)),
        TvApp("iQIYI", "com.iqiyi.i18n.tv", Color.rgb(0, 190, 145)),
        TvApp("Spotify", "com.spotify.tv.android", Color.rgb(30, 215, 96))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        buildHome()
        updateClock()
        loadWeatherAndPrayer()
        thread {
            while (!isFinishing) {
                Thread.sleep(30_000)
                runOnUiThread { updateClock() }
            }
        }
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(54, 34, 54, 30)
            gravity = Gravity.TOP
            background = wallpaperBackground()
            isFocusable = true
            isFocusableInTouchMode = true
        }
        setContentView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        greeting = text("GOOD EVENING", 16, 0xFFE0E8F2.toInt(), true)
        clock = text("20:08", 58, white, true)
        dateText = text("Minggu, 1 November", 15, 0xFFD1DAE5.toInt(), false)
        weatherText = text("Memuat cuaca Kebasen…", 15, white, false)
        forecastText = text("Memuat prakiraan…", 12, 0xFFD1DAE5.toInt(), false)
        prayerText = text("Memuat jadwal salat…", 14, 0xFFE2E8F0.toInt(), false)
        left.addView(greeting)
        left.addView(clock)
        left.addView(dateText)
        left.addView(weatherText)
        left.addView(forecastText)
        left.addView(prayerText)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))

        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP or Gravity.END
        }
        chips.addView(chip("▣  INPUT") { showInputDialog() })
        chips.addView(chip("◉  WI-FI") { openWifiSettings() })
        chips.addView(chip("☷  CONTROL") { showControlDialog() })
        top.addView(chips)
        root.addView(top)

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val center = TextView(this).apply {
            text = "A CALMER WAY TO WATCH"
            textSize = 12f
            letterSpacing = 0.24f
            setTextColor(0x99FFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(center, LinearLayout.LayoutParams(-1, 30))

        val dockPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            background = glass(0xAA111D2C.toInt(), 28)
        }
        val dockTitle = text("YOUR FAVORITES     ·     5 APPS", 11, 0xFFCFD9E5.toInt(), true)
        dockPanel.addView(dockTitle)
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        featured.forEachIndexed { index, app ->
            dock.addView(dockItem(app, index), LinearLayout.LayoutParams(0, 92, 1f))
        }
        dockPanel.addView(dock)
        root.addView(dockPanel, LinearLayout.LayoutParams(-1, -2))
        pageLabel = text("KAABA OS  ·  HOME     ↓  APP LIBRARY", 10, 0x99FFFFFF.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        root.addView(pageLabel)
        dock.getChildAt(0)?.requestFocus()
    }

    private fun wallpaperBackground(): android.graphics.drawable.Drawable {
        return try {
            val bmp = assets.open("kaaba_wallpaper.jpg").use { BitmapFactory.decodeStream(it) }
            val photo = BitmapDrawable(resources, bmp).apply { gravity = Gravity.FILL }
            val shade = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x66071321, 0x22071321, 0x88071321)
            )
            LayerDrawable(arrayOf(photo, shade))
        } catch (_: Exception) {
            GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF071321.toInt(), 0xFF243A51.toInt(), 0xFF071321.toInt()))
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL)
                       else Typeface.create("sans-serif", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }

    private fun glass(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(1, 0x44FFFFFF)
        }

    private fun chip(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(white)
            background = glass(0x661B2A3D, 40)
            setPadding(12, 4, 12, 4)
            isFocusable = true
            setOnClickListener { action() }
            setOnFocusChangeListener { v, hasFocus ->
                v.animate().scaleX(if (hasFocus) 1.06f else 1f)
                    .scaleY(if (hasFocus) 1.06f else 1f).setDuration(150).start()
                if (hasFocus) background = glass(0xCC30445E.toInt(), 40)
                else background = glass(0x661B2A3D, 40)
            }
        }

    private fun dockItem(app: TvApp, index: Int): View {
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            background = glass(0x44FFFFFF, 20)
            setPadding(6, 8, 6, 5)
        }
        val iconView = android.widget.ImageView(this).apply {
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            try {
                val appIcon = packageManager.getApplicationIcon(app.pkg)
                setImageDrawable(appIcon)
            } catch (_: Exception) {
                setImageResource(android.R.drawable.ic_menu_view)
            }
        }
        val label = text(app.label, 12, white, true).apply { gravity = Gravity.CENTER }
        holder.addView(iconView, LinearLayout.LayoutParams(52, 48).apply { gravity = Gravity.CENTER })
        holder.addView(label)
        holder.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) 1.17f else 1f)
                .scaleY(if (hasFocus) 1.17f else 1f)
                .translationY(if (hasFocus) -7f else 0f)
                .setDuration(180).setInterpolator(DecelerateInterpolator()).start()
            holder.background = if (hasFocus) glass(blend(app.tint, 0x55202B3A), 20)
                                 else glass(0x44FFFFFF, 20)
        }
        holder.setOnClickListener { launchApp(app.pkg, app.label) }
        holder.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                showLibrary()
                true
            } else false
        }
        return holder
    }

    private fun blend(color: Int, overlay: Int): Int {
        val a = (overlay ushr 24) and 255
        fun mix(c1: Int, c2: Int) = (((c1 * (255 - a)) + (c2 * a)) / 255)
        return Color.rgb(mix(Color.red(color), Color.red(overlay)),
            mix(Color.green(color), Color.green(overlay)),
            mix(Color.blue(color), Color.blue(overlay)))
    }

    private fun launchApp(pkg: String, label: String) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            openedApps.add(label)
            getSharedPreferences("kaaba", MODE_PRIVATE).edit()
                .putStringSet("recent", openedApps).apply()
            startActivity(intent)
        } else {
            AlertDialog.Builder(this).setTitle(label)
                .setMessage("Aplikasi ini belum ditemukan. Pastikan sudah terpasang di Google TV.")
                .setPositiveButton("OK", null).show()
        }
    }

    private fun updateClock() {
        val now = Date()
        val hour = SimpleDateFormat("H", Locale.getDefault()).format(now).toInt()
        greeting.text = when (hour) {
            in 5..10 -> "GOOD MORNING"
            in 11..14 -> "GOOD AFTERNOON"
            in 15..17 -> "GOOD EVENING"
            else -> "GOOD EVENING"
        }
        clock.text = SimpleDateFormat("HH:mm", Locale("id", "ID")).format(now)
        dateText.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(now)
            .replaceFirstChar { it.uppercase() }
    }

    private fun loadWeatherAndPrayer() {
        thread {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=-7.53&longitude=109.20&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=Asia%2FJakarta&forecast_days=7")
                val json = JSONObject(url.readText())
                val current = json.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").toInt()
                val desc = weatherDescription(current.getInt("weather_code"))
                val daily = json.getJSONObject("daily")
                val forecast = (0 until minOf(5, daily.getJSONArray("time").length())).joinToString("   ") {
                    val day = daily.getJSONArray("time").getString(it).substring(5)
                    "$day ${daily.getJSONArray("temperature_2m_max").getDouble(it).toInt()}°"
                }
                runOnUiThread {
                    weatherText.text = "Kebasen, Banyumas  ·  $desc  ·  $temp°C"
                    forecastText.text = "7 HARI  ·  $forecast"
                }
            } catch (_: Exception) {
                runOnUiThread { weatherText.text = "Kebasen, Banyumas  ·  Cuaca offline"; forecastText.text = "Prakiraan tidak tersedia offline" }
            }
            try {
                val url = URL("https://api.aladhan.com/v1/timingsByCity?city=Banyumas&country=Indonesia&method=20")
                val json = JSONObject(url.readText()).getJSONObject("data").getJSONObject("timings")
                val names = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                val display = names.joinToString("   ") { "${it.take(2)} ${json.getString(it)}" }
                runOnUiThread { prayerText.text = "Waktu salat  ·  $display" }
            } catch (_: Exception) { }
        }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "Cerah"; 1, 2 -> "Cerah berawan"; 3 -> "Berawan"
        in 45..48 -> "Berkabut"; in 51..67 -> "Hujan ringan"
        in 71..77 -> "Salju"; in 80..82 -> "Hujan"
        in 95..99 -> "Badai petir"; else -> "Berawan"
    }

    private fun showInputDialog() {
        val options = arrayOf("HDMI 1", "HDMI 2", "HDMI 3", "TV / Antena", "AV", "Buka pengaturan input")
        AlertDialog.Builder(this).setTitle("Input Connector")
            .setItems(options) { _, which ->
                if (which == 5) openSystemSettings()
                else AlertDialog.Builder(this).setMessage(
                    "Pemilihan input ${options[which]} bergantung pada dukungan firmware Google TV. Launcher biasa tidak memiliki izin sistem untuk mengganti HDMI secara langsung."
                ).setPositiveButton("Mengerti", null).show()
            }.show()
    }

    private fun openWifiSettings() {
        try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        catch (_: Exception) { openSystemSettings() }
    }

    private fun openSystemSettings() {
        try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
    }

    private fun showControlDialog() {
        val options = arrayOf("Pengaturan sistem", "Suara & tampilan", "Informasi KAABA OS", "Pilih launcher bawaan")
        AlertDialog.Builder(this).setTitle("Control Center")
            .setItems(options) { _, which ->
                when (which) {
                    0, 1 -> openSystemSettings()
                    2 -> AlertDialog.Builder(this).setTitle("KAABA OS v1.0.0")
                        .setMessage("Launcher alternatif untuk Google TV. Dibuat dengan Kotlin.")
                        .setPositiveButton("OK", null).show()
                    3 -> {
                        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                        catch (_: Exception) { openSystemSettings() }
                    }
                }
            }.show()
    }

    private fun showLibrary() {
        if (libraryOpen) return
        libraryOpen = true
        root.removeAllViews()
        root.setPadding(48, 28, 48, 24)
        root.addView(text("APP LIBRARY", 30, white, true))
        root.addView(text("Semua aplikasi yang terpasang di Google TV", 14, 0xFFD1DAE5.toInt(), false))
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 5 }
        val apps = packageManager.getInstalledApplications(0)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null ||
                      packageManager.getLeanbackLaunchIntentForPackage(it.packageName) != null }
            .distinctBy { it.packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        apps.forEach { info ->
            val label = packageManager.getApplicationLabel(info).toString()
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = glass(0x55202F42, 18)
                setPadding(8, 12, 8, 12)
                val icon = packageManager.getApplicationIcon(info)
                val image = android.widget.ImageView(this@MainActivity).apply {
                    setImageDrawable(icon)
                    scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                }
                addView(image, LinearLayout.LayoutParams(64, 64))
                addView(text(label, 12, white, true).apply { gravity = Gravity.CENTER })
                setOnClickListener { launchApp(info.packageName, label) }
                setOnFocusChangeListener { v, focus ->
                    v.animate().scaleX(if (focus) 1.12f else 1f).scaleY(if (focus) 1.12f else 1f)
                        .setDuration(150).start()
                    background = glass(if (focus) 0xCC405B78.toInt() else 0x55202F42, 18)
                }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = 116
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            grid.addView(item, lp)
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val back = chip("←  KEMBALI KE HOME") { buildHome(); libraryOpen = false }
        root.addView(back)
        grid.getChildAt(0)?.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && libraryOpen) {
            buildHome()
            libraryOpen = false
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP && !libraryOpen) {
            // Let normal focus navigation move to the top controls.
        }
        return super.onKeyDown(keyCode, event)
    }
}
