# KAABA OS TV

Launcher alternatif Android TV / Google TV berbasis Kotlin.

## Build
Project ini dibangun melalui GitHub Actions:
1. Upload seluruh isi folder project ke repository GitHub.
2. Buka tab Actions.
3. Jalankan workflow `Build KAABA OS APK`.
4. Unduh artifact `KAABA-OS-debug`.
5. Ekstrak APK dari artifact ZIP.

## Install
Gunakan ADB Wi-Fi dari HP Android ke Google TV:
`adb connect IP_TV:PORT`
`adb install -r app-debug.apk`

## Catatan kompatibilitas
- Launcher lama tidak dihapus atau dinonaktifkan.
- Google TV/firmware menentukan apakah aplikasi pihak ketiga boleh dipilih sebagai Home.
- Penggantian input HDMI secara langsung membutuhkan hak sistem/vendor API; menu Input di versi ini merupakan pintasan dan penjelasan kompatibilitas.
- Riwayat tontonan Netflix/YouTube tidak dapat dibaca secara universal. Continue Watching lintas aplikasi memerlukan integrasi resmi.
- Weather menggunakan Open-Meteo dan jadwal salat menggunakan Aladhan; koneksi internet diperlukan.
- Wallpaper awal menggunakan foto referensi malam. Wallpaper pagi/siang dapat ditambahkan sebagai aset terpisah pada iterasi desain berikutnya.
- Nama paket aplikasi unggulan dapat berbeda antar perangkat/region; sesuaikan konstanta `featured` di `MainActivity.kt`.
